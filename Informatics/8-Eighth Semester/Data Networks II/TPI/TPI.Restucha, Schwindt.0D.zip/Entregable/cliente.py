import socket
import time

# --- Configuración ---
IP_SERVIDOR = "80.0.2.2"  # IP del nodo n9
BUFFER_SIZE = 1024
TIMEOUT = 3  # Segundos de espera

def probar_servicio(puerto, mensaje):
    """
    Función genérica para conectarse, enviar un mensaje y recibir una respuesta.
    """
    
    if puerto == 7:
        nombre_servicio = "ECHO"
    elif puerto == 9:
        nombre_servicio = "DISCARD"
    else:
        nombre_servicio = f"Puerto {puerto}"

    print(f"\n--- Probando servicio: {nombre_servicio} (Puerto {puerto}) ---")

    # 1. Crear el socket TCP
    # 'with' se asegura de que el socket se cierre al final
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            # Poner un límite de tiempo para la conexión y recepción
            sock.settimeout(TIMEOUT)

            # 2. Conectar al servidor
            print(f"Conectando a {IP_SERVIDOR}:{puerto}...")
            sock.connect((IP_SERVIDOR, puerto))
            print("¡Conectado!")

            # 3. Enviar datos
            mensaje_bytes = mensaje.encode('utf-8')
            print(f"Enviando: '{mensaje}'")
            sock.sendall(mensaje_bytes)

            # 4. Esperar respuesta
            print("Esperando respuesta...")
            datos_recibidos = sock.recv(BUFFER_SIZE)

            if datos_recibidos:
                # El servicio ECHO devolverá datos
                print(f"Recibido: '{datos_recibidos.decode('utf-8')}'")
            else:
                # Esto pasaría si el servidor cierra la conexión
                print("El servidor cerró la conexión sin enviar datos.")

        except socket.timeout:
            # El servicio DISCARD no responderá y esto se activará
            print(f"No se recibió respuesta después de {TIMEOUT} segundos. (Comportamiento esperado para DISCARD)")
        except ConnectionRefusedError:
            print(f"ERROR: Conexión rechazada. ¿Está el servicio corriendo en n9 en el puerto {puerto}?")
        except Exception as e:
            print(f"Ocurrió un error inesperado: {e}")
        finally:
            print("Cerrando conexión.")

# --- Bloque principal de ejecución ---
if __name__ == "__main__":
    print(f"Cliente iniciando... Objetivo: {IP_SERVIDOR}\n")
    
    # Prueba 1: Conexión a ECHO (Puerto 7)
    probar_servicio(puerto=7, mensaje="Hola servicio ECHO")
    
    # Pausa para que se vea claro en la terminal
    time.sleep(2)
    
    # Prueba 2: Conexión a DISCARD (Puerto 9)
    # (Este es el puerto estándar que vimos en tu 'netstat')
    probar_servicio(puerto=9, mensaje="Hola servicio DISCARD")
    
    print("\n--- Pruebas completadas ---")
