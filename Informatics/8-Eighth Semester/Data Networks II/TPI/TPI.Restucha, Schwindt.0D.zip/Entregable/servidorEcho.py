import socket

class ServidorEchoUDP:
    """
    Una clase para representar un servidor de eco UDP.
    """
    def __init__(self, host_local, puerto_local):
        self.host_local = host_local
        self.puerto_local = puerto_local
        self.direccion_local = (host_local, puerto_local)
        self.buffer_size = 1024
        
        # Crear y vincular el socket
        self.servidor_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.servidor_socket.bind(self.direccion_local)

    def iniciar(self):
        """
        Inicia el bucle principal del servidor para escuchar.
        """
        print(f"Servidor UDP Echo escuchando en {self.host_local}:{self.puerto_local}")
        
        try:
            while True:
                # Esperar y recibir datos
                datos_recibidos, direccion_cliente = self.servidor_socket.recvfrom(self.buffer_size)
                
                print(f"Mensaje recibido de {direccion_cliente}: {datos_recibidos.decode()}")
                
                # Enviar los mismos datos de vuelta (eco)
                self.servidor_socket.sendto(datos_recibidos, direccion_cliente)
                
        except KeyboardInterrupt:
            print("\nServidor detenido por el usuario (Ctrl+C).")
        except Exception as e:
            print(f"Ocurrio un error inesperado: {e}")
        finally:
            # Asegurarse de cerrar el socket al terminar
            self.servidor_socket.close()
            print("Socket del servidor cerrado.")

# --- Bloque principal de ejecucion ---
if __name__ == "__main__":
    
    # Configuracion
    IP_ESCUCHA = "0.0.0.0"  # Escucha en todas las interfaces
    PUERTO_ESCUCHA = 7
    
    # Instanciar y arrancar el servidor
    servidor = ServidorEchoUDP(IP_ESCUCHA, PUERTO_ESCUCHA)
    servidor.iniciar()
