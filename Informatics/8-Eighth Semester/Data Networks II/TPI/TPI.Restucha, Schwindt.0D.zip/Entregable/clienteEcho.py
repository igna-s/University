import socket

class ClienteEchoUDP:
    """
    Una clase para representar un cliente de eco UDP.
    """
    def __init__(self, host, puerto):
        self.host_destino = host
        self.puerto_destino = puerto
        self.direccion_servidor = (host, puerto)
        self.buffer_size = 1024
        
        # Crear el socket al iniciar la clase
        self.cliente_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def enviar_mensaje(self, payload):
        """
        Envia un mensaje y espera la respuesta.
        """
        try:
            print(f"Enviando: {payload}")
            # Enviar datos
            self.cliente_socket.sendto(payload.encode(), self.direccion_servidor)
            
            # Recibir respuesta
            datos_recibidos, _ = self.cliente_socket.recvfrom(self.buffer_size)
            print(f"Recibido: {datos_recibidos.decode()}")
            
        except socket.timeout:
            print("Error: La solicitud supero el tiempo de espera.")
        except Exception as e:
            print(f"Ocurrio un error: {e}")
        finally:
            # Cerrar el socket
            self.cliente_socket.close()
            print("Socket cerrado.")

# --- Bloque principal de ejecucion ---
if __name__ == "__main__":
    
    # Configuracion
    IP_OBJETIVO = "80.0.2.2"
    PUERTO_OBJETIVO = 7
    MENSAJE_A_ENVIAR = "Hola, servidor UDP Echo"

    # Instanciar y usar el cliente
    cliente = ClienteEchoUDP(IP_OBJETIVO, PUERTO_OBJETIVO)
    cliente.enviar_mensaje(MENSAJE_A_ENVIAR)
