import socket
import threading

class ServidorEchoTCP:
    """
    Una clase para representar un servidor de eco TCP.
    Maneja a cada cliente en un hilo separado.
    """
    def __init__(self, host_local, puerto_local):
        self.host_local = host_local
        self.puerto_local = puerto_local
        self.direccion_local = (host_local, puerto_local)
        self.buffer_size = 1024
        
        # Crear y vincular el socket de escucha
        self.servidor_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.servidor_socket.bind(self.direccion_local)

    def manejar_cliente(self, socket_cliente, direccion_cliente):
        """
        Esta funcion se ejecuta en un hilo para cada cliente.
        """
        print(f"[NUEVA CONEXION] {direccion_cliente} conectado.")
        
        try:
            while True:
                # Recibir datos del cliente
                datos_recibidos = socket_cliente.recv(self.buffer_size)
                
                # Si no se reciben datos, el cliente se desconecto
                if not datos_recibidos:
                    print(f"[DESCONEXION] {direccion_cliente} desconectado.")
                    break
                
                print(f"Mensaje recibido de {direccion_cliente}: {datos_recibidos.decode()}")
                
                # Enviar los mismos datos de vuelta (eco)
                # Usamos sendall para asegurar que todo se envie
                socket_cliente.sendall(datos_recibidos)
                
        except ConnectionResetError:
            print(f"[ERROR] Conexion con {direccion_cliente} reiniciada forzosamente.")
        except Exception as e:
            print(f"[ERROR] Ocurrio un error con {direccion_cliente}: {e}")
        finally:
            # Cerrar el socket de este cliente
            socket_cliente.close()
            print(f"[CONEXION CERRADA] {direccion_cliente}.")

    def iniciar(self):
        """
        Inicia el bucle principal del servidor para escuchar conexiones.
        """
        # Poner el socket en modo de escucha
        self.servidor_socket.listen()
        print(f"Servidor TCP Echo escuchando en {self.host_local}:{self.puerto_local}")
        
        try:
            while True:
                # Esperar (bloqueante) por una nueva conexion
                socket_cliente, direccion_cliente = self.servidor_socket.accept()
                
                # Crear un nuevo hilo para manejar a este cliente
                hilo_cliente = threading.Thread(
                    target=self.manejar_cliente, 
                    args=(socket_cliente, direccion_cliente)
                )
                hilo_cliente.start()
                
        except KeyboardInterrupt:
            print("\nServidor detenido por el usuario (Ctrl+C).")
        except Exception as e:
            print(f"Ocurrio un error inesperado en el servidor: {e}")
        finally:
            # Asegurarse de cerrar el socket principal
            self.servidor_socket.close()
            print("Socket del servidor cerrado.")

# --- Bloque principal de ejecucion ---
if __name__ == "__main__":
    
    IP_ESCUCHA = "0.0.0.0"  # Escucha en todas las interfaces
    PUERTO_ESCUCHA = 9000
    
    servidor = ServidorEchoTCP(IP_ESCUCHA, PUERTO_ESCUCHA)
    servidor.iniciar()
